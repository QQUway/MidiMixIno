# Usage

Upload files to pendrive which will be inserted into esp32 S2 and use `#define SERVE_WEB_FROM_PENDRIVE 1`.