#pragma once

#include "BLEMIDI_Namespace.h"

BEGIN_BLEMIDI_NAMESPACE

struct DefaultSettings
{
    static const size_t MaxBufferSize = 64;
};

END_BLEMIDI_NAMESPACE
